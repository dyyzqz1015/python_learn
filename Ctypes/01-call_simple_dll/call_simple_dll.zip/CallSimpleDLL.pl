#!/usr/bin/perl -w
use strict;

#include Win32::API to call DLLs
use Win32::API;

my $x = 5;
my $y = 8;
#First pack $sum as an Int32 since we have to pass this by reference
my $sum = pack('i', 0);
my $string = " " x 20;

#Function Prototype: int addNumbers (int x, int y, int *sum, char *string)

#Load the Function
#The third argument here 'IIPP' refers to the types of the paramters,
#i.e., two integers (I) followed by two pointers(P)
#The fourth argument here 'I' refers to the return type, i.e., an integer.
my $function = Win32::API->new('SimpleDLL','addNumbers','IIPP','I', '_cdecl');

#Call the Function
my $return = $function->Call($x,$y,$sum,$string);

#Unpack the sum back to a regular perl number
my $sumUnpacked = unpack('i', $sum);

#Print Results
print "Sum: ", $sumUnpacked, "\n";
print "String: ", $string, "\n";
print "ReturnValue: ", $return, "\n";